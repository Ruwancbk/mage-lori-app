package lk.ruwancbk.magelori;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Looks for fuel stations (shed / gas station / fuel station / ඉන්ධන පිරවුම් හල) within 250 m.
 * Sources: 1) OpenStreetMap (Overpass) - tags + name keywords, 2) Android Geocoder keyword search.
 * Results are cached for 60 s / 40 m so the page can "search" every 5 s without hammering the network.
 */
public class StationFinder {
    static final int RADIUS = 250;

    private static final String[] SERVERS = {
            "https://overpass-api.de/api/interpreter",
            "https://overpass.private.coffee/api/interpreter",
            "https://overpass.kumi.systems/api/interpreter",
            "https://overpass.openstreetmap.fr/api/interpreter"
    };
    private static final String[] KEYWORDS = {
            "fuel station", "gas station", "petrol shed", "shed", "ඉන්ධන පිරවුම් හල"
    };
    // ASCII words are matched case-insensitively; Sinhala words are matched in a separate clause
    // WITHOUT the ",i" flag (case-insensitive regex on non-ASCII text makes some Overpass servers
    // answer HTTP 400 - that made the app think there was "no internet").
    private static final String NAME_RE = "fuel|petrol|gas station|filling|shed|ceypetco|ioc";
    private static final String NAME_RE_SI = "ඉන්ධන|පිරවුම්";
    private static final String UA = "MageLori/2.0 (Android; fuel station finder)";
    private static final long TOTAL_BUDGET_MS = 22000L;
    private static final long RETRY_AFTER_FAIL_MS = 8000L;

    private static final Object LOCK = new Object();
    private static List<Item> cache = null;
    private static boolean cacheNet = false;
    private static boolean cacheOk = false;
    private static double cacheLat, cacheLng;
    private static long cacheTime = 0L;
    private static long failUntil = 0L;
    private static volatile boolean busy = false;
    private static volatile String lastErr = "";

    private static String host(String u) {
        try { return new URL(u).getHost(); } catch (Exception e) { return u; }
    }

    interface Callback {
        void done(String json);
    }

    static class Item {
        String name;
        double lat, lng;
        String src;
        double d;

        Item(String name, double lat, double lng, String src) {
            this.name = name;
            this.lat = lat;
            this.lng = lng;
            this.src = src;
        }
    }

    /** Outcome of one online source. */
    static class Result {
        boolean reached;   // some server answered (so the phone does have internet)
        boolean success;   // a server answered with usable data
    }

    static double dist(double a, double b, double c, double d) {
        double r = Math.PI / 180.0;
        double dl = (c - a) * r, dg = (d - b) * r;
        double x = Math.sin(dl / 2) * Math.sin(dl / 2)
                + Math.cos(a * r) * Math.cos(c * r) * Math.sin(dg / 2) * Math.sin(dg / 2);
        return 2 * 6371000.0 * Math.asin(Math.sqrt(x));
    }

    static void find(final Context ctx, final double lat, final double lng, final Callback cb) {
        synchronized (LOCK) {
            if (cache != null && cacheOk && System.currentTimeMillis() - cacheTime < 60000L
                    && dist(lat, lng, cacheLat, cacheLng) < 40.0) {
                cb.done(build(lat, lng, cache, cacheNet));
                return;
            }
            // last search failed: wait a few seconds before hammering the servers again,
            // but keep showing the last known list (if any) so the page never looks frozen
            if (System.currentTimeMillis() < failUntil) {
                if (cache != null) cb.done(build(lat, lng, cache, cacheNet));
                return;
            }
        }
        if (busy) return; // a search is already running; the next 5 s tick will get its result
        busy = true;
        final Context app = ctx.getApplicationContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    List<Item> items = new ArrayList<Item>();
                    long deadline = System.currentTimeMillis() + TOTAL_BUDGET_MS;
                    Result r = overpass(lat, lng, items, deadline);
                    if (!r.success && System.currentTimeMillis() < deadline) {
                        Result n = nominatim(lat, lng, items);
                        r.reached = r.reached || n.reached;
                        r.success = r.success || n.success;
                    }
                    if (items.isEmpty()) geocoderSearch(app, lat, lng, items);
                    List<Item> uniq = dedupe(items);
                    synchronized (LOCK) {
                        cacheOk = r.success || !uniq.isEmpty();
                        if (cacheOk) {
                            cache = uniq;
                            cacheNet = r.reached || r.success;
                            cacheLat = lat;
                            cacheLng = lng;
                            cacheTime = System.currentTimeMillis();
                            failUntil = 0L;
                        } else {
                            failUntil = System.currentTimeMillis() + RETRY_AFTER_FAIL_MS;
                        }
                    }
                    // net=false only when NO server could be reached at all (real offline).
                    // If servers were reachable but busy, say net=true / ok=false (temporary error).
                    cb.done(build(lat, lng, uniq, r.reached || r.success, cacheOk));
                } catch (Exception e) {
                    synchronized (LOCK) {
                        failUntil = System.currentTimeMillis() + RETRY_AFTER_FAIL_MS;
                    }
                    cb.done(build(lat, lng, new ArrayList<Item>(), false, false));
                } finally {
                    busy = false;
                }
            }
        }).start();
    }

    private static String build(double lat, double lng, List<Item> items, boolean net) {
        return build(lat, lng, items, net, true);
    }

    private static String build(double lat, double lng, List<Item> items, boolean net, boolean searchOk) {
        List<Item> near = new ArrayList<Item>();
        for (Item it : items) {
            it.d = dist(lat, lng, it.lat, it.lng);
            if (it.d <= RADIUS) near.add(it);
        }
        Collections.sort(near, new Comparator<Item>() {
            @Override
            public int compare(Item a, Item b) {
                return Double.compare(a.d, b.d);
            }
        });
        JSONObject o = new JSONObject();
        JSONArray arr = new JSONArray();
        try {
            for (int i = 0; i < near.size() && i < 6; i++) {
                Item it = near.get(i);
                JSONObject j = new JSONObject();
                j.put("n", it.name);
                j.put("d", Math.round(it.d));
                j.put("la", it.lat);
                j.put("lo", it.lng);
                j.put("s", it.src);
                arr.put(j);
            }
            o.put("ok", true);
            o.put("net", net);
            o.put("sok", searchOk);
            o.put("err", searchOk ? "" : lastErr);
            o.put("lat", lat);
            o.put("lng", lng);
            o.put("list", arr);
        } catch (JSONException ignored) { }
        return o.toString();
    }

    private static List<Item> dedupe(List<Item> in) {
        List<Item> out = new ArrayList<Item>();
        for (Item a : in) {
            boolean dup = false;
            for (Item b : out) {
                if (b.name.equalsIgnoreCase(a.name) || dist(a.lat, a.lng, b.lat, b.lng) < 30.0) {
                    dup = true;
                    break;
                }
            }
            if (!dup) out.add(a);
        }
        return out;
    }

    /** OpenStreetMap lookup: amenity=fuel plus anything whose name looks like a fuel station. */
    private static Result overpass(double lat, double lng, List<Item> items, long deadline) {
        Result res = new Result();
        String around = String.format(Locale.US, "(around:%d,%.6f,%.6f)", RADIUS, lat, lng);
        String q = "[out:json][timeout:10];("
                + "nwr[\"amenity\"=\"fuel\"]" + around + ";"
                + "nwr[\"shop\"=\"fuel\"]" + around + ";"
                + "nwr[\"name\"~\"" + NAME_RE + "\",i]" + around + ";"
                + ");out center tags;";
        for (String server : SERVERS) {
            if (System.currentTimeMillis() > deadline) break;
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(server).openConnection();
                c.setConnectTimeout(5000);
                c.setReadTimeout(12000);
                c.setRequestMethod("POST");
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                c.setRequestProperty("User-Agent", UA);
                byte[] body = ("data=" + URLEncoder.encode(q, "UTF-8")).getBytes("UTF-8");
                OutputStream os = c.getOutputStream();
                os.write(body);
                os.close();
                int code = c.getResponseCode();
                res.reached = true; // the server answered, so there IS internet
                if (code != 200) { lastErr = host(server) + " HTTP " + code; continue; }
                String text = readAll(c.getInputStream());
                JSONObject root = new JSONObject(text);
                String remark = root.optString("remark", "");
                if (remark.length() > 0 && remark.toLowerCase(Locale.US).contains("error")) { lastErr = host(server) + " " + remark; continue; }
                JSONArray els = root.getJSONArray("elements");
                for (int i = 0; i < els.length(); i++) {
                    JSONObject e = els.getJSONObject(i);
                    JSONObject tags = e.optJSONObject("tags");
                    if (tags == null) continue;
                    String name = firstNonEmpty(tags.optString("name:si"), tags.optString("name"),
                            tags.optString("name:en"), tags.optString("brand"), tags.optString("operator"));
                    if (name == null) continue;
                    double la, lo;
                    if (e.has("lat")) {
                        la = e.getDouble("lat");
                        lo = e.getDouble("lon");
                    } else if (e.has("center")) {
                        la = e.getJSONObject("center").getDouble("lat");
                        lo = e.getJSONObject("center").getDouble("lon");
                    } else {
                        continue;
                    }
                    items.add(new Item(name, la, lo, "osm"));
                }
                res.success = true;
                return res;
            } catch (Exception ex) {
                lastErr = host(server) + " " + ex.getClass().getSimpleName();
                // try the next server
            } finally {
                if (c != null) c.disconnect();
            }
        }
        return res;
    }

    /** Second online source (Nominatim) used when every Overpass server failed. */
    private static Result nominatim(double lat, double lng, List<Item> items) {
        Result res = new Result();
        HttpURLConnection c = null;
        try {
            double dLat = RADIUS / 111320.0;
            double dLng = RADIUS / (111320.0 * Math.max(0.2, Math.cos(Math.toRadians(lat))));
            String url = String.format(Locale.US,
                    "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=10&bounded=1"
                            + "&viewbox=%.6f,%.6f,%.6f,%.6f&q=%s",
                    lng - dLng, lat + dLat, lng + dLng, lat - dLat,
                    URLEncoder.encode("[amenity=fuel]", "UTF-8"));
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(5000);
            c.setReadTimeout(8000);
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            res.reached = true;
            if (code != 200) { lastErr = "nominatim HTTP " + code; return res; }
            JSONArray arr = new JSONArray(readAll(c.getInputStream()));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject e = arr.getJSONObject(i);
                String name = firstNonEmpty(e.optString("name"), e.optString("display_name").split(",")[0]);
                if (name == null) continue;
                items.add(new Item(name, e.getDouble("lat"), e.getDouble("lon"), "osm"));
            }
            res.success = true;
        } catch (Exception ex) {
            lastErr = "nominatim " + ex.getClass().getSimpleName();
        } finally {
            if (c != null) c.disconnect();
        }
        return res;
    }

    private static String readAll(InputStream is) throws java.io.IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }

    private static String firstNonEmpty(String... v) {
        for (String s : v) {
            if (s != null && s.trim().length() > 0) return s.trim();
        }
        return null;
    }

    /** Keyword search with the phone's geocoder, limited to a box of about RADIUS metres. */
    @SuppressWarnings("deprecation")
    private static void geocoderSearch(Context ctx, double lat, double lng, List<Item> items) {
        try {
            if (!Geocoder.isPresent()) return;
            Geocoder g = new Geocoder(ctx);
            double dLat = RADIUS / 111320.0;
            double dLng = RADIUS / (111320.0 * Math.max(0.2, Math.cos(Math.toRadians(lat))));
            for (String kw : KEYWORDS) {
                try {
                    List<Address> list = g.getFromLocationName(kw, 5,
                            lat - dLat, lng - dLng, lat + dLat, lng + dLng);
                    if (list == null) continue;
                    for (Address a : list) {
                        if (!a.hasLatitude() || !a.hasLongitude()) continue;
                        String name = a.getFeatureName();
                        if ((name == null || name.matches("[0-9\\s/\\-]+")) && a.getMaxAddressLineIndex() >= 0) {
                            String line = a.getAddressLine(0);
                            if (line != null) name = line.split(",")[0].trim();
                        }
                        if (name == null || name.trim().length() == 0 || name.matches("[0-9\\s/\\-]+")) continue;
                        items.add(new Item(name.trim(), a.getLatitude(), a.getLongitude(), "geo"));
                    }
                } catch (java.io.IOException ioe) {
                    return; // no network / geocoder backend: stop trying
                }
            }
        } catch (Exception ignored) { }
    }
}
