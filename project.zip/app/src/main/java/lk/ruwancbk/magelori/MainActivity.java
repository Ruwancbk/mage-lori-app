package lk.ruwancbk.magelori;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 77;
    private static final int REQ_NOTIFY = 78;
    private WebView webView;
    private boolean askedPerm = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(5, 45, 104));
        getWindow().setNavigationBarColor(Color.rgb(5, 45, 104));
        getWindow().getDecorView().setSystemUiVisibility(0);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(245, 248, 253));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new TripBridge(), "AndroidTrip");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private SharedPreferences tripPrefs() {
        return getSharedPreferences(TripService.PREFS, MODE_PRIVATE);
    }

    private boolean hasLocationPermission() {
        return Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean gpsEnabled() {
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            return lm != null && lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception e) {
            return false;
        }
    }

    private void requestLocationPerms() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION,
                            "android.permission.POST_NOTIFICATIONS"}, REQ_LOCATION);
                } else if (Build.VERSION.SDK_INT >= 23) {
                    requestPermissions(new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
                }
            }
        });
    }

    /** Starts (or refreshes) the GPS service. Odometer counting begins as soon as GPS is on. */
    private void startTracking() {
        if (!hasLocationPermission()) return;
        tripPrefs().edit().putBoolean("tracking", true).apply();
        Intent svc = new Intent(this, TripService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(svc);
            } else {
                startService(svc);
            }
        } catch (RuntimeException ignored) { }
    }

    @Override
    protected void onStop() {
        if (webView != null) webView.evaluateJavascript("window.appLeft&&appLeft()", null);
        super.onStop();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (webView != null) webView.evaluateJavascript("window.appBack&&appBack()", null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (hasLocationPermission()) {
            startTracking();
        } else if (!askedPerm) {
            askedPerm = true;
            requestLocationPerms();
        }
    }

    @Override
    protected void onDestroy() {
        if (isFinishing() && !tripPrefs().getBoolean("hireOn", false)) {
            tripPrefs().edit().putBoolean("tracking", false).apply();
            stopService(new Intent(this, TripService.class));
        }
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION && webView != null) {
            final boolean ok = hasLocationPermission();
            if (ok) startTracking();
            webView.post(new Runnable() {
                @Override
                public void run() {
                    webView.evaluateJavascript("tripPermResult(" + ok + ")", null);
                }
            });
        }
    }

    private Location freshFix() {
        long now = System.currentTimeMillis();
        Location f = TripService.lastFix;
        if (f != null && now - f.getTime() < 120000L) return f;
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            Location k = lm == null ? null : lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (k != null && now - k.getTime() < 120000L) return k;
        } catch (SecurityException ignored) { }
        return null;
    }

    private Location anyFix() {
        Location f = TripService.lastFix;
        if (f != null) return f;
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            return lm == null ? null : lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        } catch (SecurityException e) {
            return null;
        }
    }

    /** Called from JavaScript as window.AndroidTrip */
    public class TripBridge {

        // ---------------- Odometer (independent of hire) ----------------

        /** Returns metres driven since the last call and resets the counter. */
        @JavascriptInterface
        public double takeOdoMeters() {
            synchronized (TripService.LOCK) {
                SharedPreferences sp = tripPrefs();
                double m = TripService.getD(sp, "odoPend", 0d);
                SharedPreferences.Editor e = sp.edit();
                TripService.putD(e, "odoPend", 0d);
                e.apply();
                return m;
            }
        }

        @JavascriptInterface
        public double peekOdoMeters() {
            synchronized (TripService.LOCK) {
                return TripService.getD(tripPrefs(), "odoPend", 0d);
            }
        }

        /** The odometer value (km) the web UI currently holds; used by service reminders. */
        @JavascriptInterface
        public void setOdoBase(double km) {
            synchronized (TripService.LOCK) {
                SharedPreferences.Editor e = tripPrefs().edit();
                TripService.putD(e, "odoBase", km);
                e.apply();
            }
        }

        /** "ok", "gps_off" or "perm" */
        @JavascriptInterface
        public String gpsStatus() {
            if (!hasLocationPermission()) return "perm";
            return gpsEnabled() ? "ok" : "gps_off";
        }

        // ---------------- Hire ON/OFF (separate function) ----------------

        @JavascriptInterface
        public String hireStart() {
            if (!License.isPro(MainActivity.this)) return "pro";
            if (!hasLocationPermission()) {
                requestLocationPerms();
                return "perm";
            }
            if (!gpsEnabled()) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                });
                return "gps_off";
            }
            Location fix = freshFix();
            synchronized (TripService.LOCK) {
                SharedPreferences.Editor e = tripPrefs().edit();
                e.putBoolean("hireOn", true);
                TripService.putD(e, "hireM", 0d);
                e.putLong("hireStartMs", System.currentTimeMillis());
                e.remove("startName");
                if (fix != null) {
                    e.putBoolean("hasStart", true);
                    TripService.putD(e, "startLat", fix.getLatitude());
                    TripService.putD(e, "startLng", fix.getLongitude());
                } else {
                    e.putBoolean("hasStart", false); // filled by the first GPS fix
                }
                e.apply();
            }
            if (fix != null) TripService.resolveStartName(MainActivity.this, fix.getLatitude(), fix.getLongitude());
            startTracking();
            return "ok";
        }

        /** Stops the hire and returns {meters,startMs,hasStart,startLat,startLng,startName,hasEnd,endLat,endLng}. */
        @JavascriptInterface
        public String hireStop() {
            JSONObject o = new JSONObject();
            Location end = anyFix();
            synchronized (TripService.LOCK) {
                SharedPreferences sp = tripPrefs();
                try {
                    o.put("meters", TripService.getD(sp, "hireM", 0d));
                    o.put("startMs", sp.getLong("hireStartMs", System.currentTimeMillis()));
                    boolean hasStart = sp.getBoolean("hasStart", false);
                    o.put("hasStart", hasStart);
                    if (hasStart) {
                        o.put("startLat", TripService.getD(sp, "startLat", 0d));
                        o.put("startLng", TripService.getD(sp, "startLng", 0d));
                        o.put("startName", sp.getString("startName", ""));
                    }
                    o.put("hasEnd", end != null);
                    if (end != null) {
                        o.put("endLat", end.getLatitude());
                        o.put("endLng", end.getLongitude());
                    }
                } catch (JSONException ignored) { }
                sp.edit().putBoolean("hireOn", false).putBoolean("hasStart", false).remove("startName").apply();
            }
            startTracking(); // refresh the notification text
            return o.toString();
        }

        @JavascriptInterface
        public boolean isHireActive() {
            return tripPrefs().getBoolean("hireOn", false);
        }

        @JavascriptInterface
        public double getHireMeters() {
            synchronized (TripService.LOCK) {
                return TripService.getD(tripPrefs(), "hireM", 0d);
            }
        }

        /** Async place-name lookup; answers through placeResolved(kind, name) in the page. */
        @JavascriptInterface
        public void geocode(final String kind, final double lat, final double lng) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String n = TripService.placeName(MainActivity.this, lat, lng);
                    final String js = "placeResolved(" + JSONObject.quote(kind) + ","
                            + JSONObject.quote(n == null ? "" : n) + ")";
                    webView.post(new Runnable() {
                        @Override
                        public void run() {
                            webView.evaluateJavascript(js, null);
                        }
                    });
                }
            }).start();
        }

        // ---------------- Service reminders ----------------

        @JavascriptInterface
        public void setService(double dueOdo, double warnKm, double interval) {
            if (!License.isPro(MainActivity.this)) dueOdo = 0; // reminders are a Pro feature
            tripPrefs().edit()
                    .putFloat("svcDue", (float) dueOdo)
                    .putFloat("svcWarnKm", (float) warnKm)
                    .putFloat("svcInterval", (float) interval)
                    .apply();
        }

        @JavascriptInterface
        public void checkOdo(double odo) {
            if (!License.isPro(MainActivity.this)) return;
            ServiceReminder.check(MainActivity.this, odo);
        }

        // ---------------- Free / Pro license ----------------

        @JavascriptInterface
        public boolean isPro() {
            return License.isPro(MainActivity.this);
        }

        @JavascriptInterface
        public String getDeviceId() {
            return License.deviceCode(MainActivity.this);
        }

        /** Returns true when the key is valid for this device (and stores it). */
        @JavascriptInterface
        public boolean activatePro(String key) {
            return License.activate(MainActivity.this, key);
        }

        @JavascriptInterface
        public void copyText(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) {
                        cm.setPrimaryClip(ClipData.newPlainText("text", text));
                        Toast.makeText(MainActivity.this, "Copy කළා", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void shareText(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(i, "Device ID යවන්න"));
                }
            });
        }

        @JavascriptInterface
        public void askNotify() {
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTIFY);
                    }
                });
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
