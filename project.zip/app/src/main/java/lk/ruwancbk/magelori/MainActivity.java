package lk.ruwancbk.magelori;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 77;
    private static final int REQ_NOTIFY = 78;
    private static final String BACKUP_FILE = "magelori_auto_backup.json";
    private WebView webView;
    private boolean askedPerm = false;
    private boolean isForeground = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(5, 45, 104));
        getWindow().setNavigationBarColor(Color.rgb(5, 45, 104));
        getWindow().getDecorView().setSystemUiVisibility(0);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(245, 248, 253));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new TripBridge(), "AndroidTrip");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private SharedPreferences tripPrefs() {
        return getSharedPreferences(TripService.PREFS, MODE_PRIVATE);
    }

    private boolean hasLocationPermission() {
        return Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean gpsEnabled() {
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            return lm != null && lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception e) {
            return false;
        }
    }

    private void requestLocationPerms() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (Build.VERSION.SDK_INT >= 23) {
                    requestPermissions(new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
                }
            }
        });
    }

    private void requestNotifyPermIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTIFY);
                }
            });
        }
    }

    /** Starts (or refreshes) the GPS service safely (Android 14+ compliant). */
    private void startTracking() {
        if (!hasLocationPermission()) return;
        tripPrefs().edit().putBoolean("tracking", true).apply();
        boolean hire = tripPrefs().getBoolean("hireOn", false);

        if (TripService.isRunning) {
            TripService.updateNotification(this, hire);
            return;
        }

        if (!isForeground && !hire) {
            return;
        }

        Intent svc = new Intent(this, TripService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(svc);
            } else {
                startService(svc);
            }
        } catch (RuntimeException ignored) { }
    }

    @Override
    protected void onStop() {
        isForeground = false;
        if (webView != null) webView.evaluateJavascript("window.appLeft&&appLeft()", null);
        super.onStop();
    }

    @Override
    protected void onStart() {
        super.onStart();
        isForeground = true;
        if (webView != null) webView.evaluateJavascript("window.appBack&&appBack()", null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        isForeground = true;
        if (hasLocationPermission()) {
            startTracking();
        } else if (!askedPerm) {
            askedPerm = true;
            requestLocationPerms();
        }
    }

    @Override
    protected void onDestroy() {
        if (isFinishing() && !tripPrefs().getBoolean("hireOn", false)) {
            tripPrefs().edit().putBoolean("tracking", false).apply();
            stopService(new Intent(this, TripService.class));
        }
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private boolean isUiAlive() {
        return !isFinishing() && !isDestroyed() && webView != null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            final boolean ok = hasLocationPermission();
            if (ok) {
                startTracking();
                requestNotifyPermIfNeeded();
            }
            if (isUiAlive()) {
                webView.post(new Runnable() {
                    @Override
                    public void run() {
                        if (isUiAlive()) {
                            webView.evaluateJavascript("tripPermResult(" + ok + ")", null);
                        }
                    }
                });
            }
        }
    }

    private Location freshFix() {
        long now = System.currentTimeMillis();
        Location f = TripService.lastFix;
        if (f != null && now - f.getTime() < 120000L) return f;
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            Location k = lm == null ? null : lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (k != null && now - k.getTime() < 120000L) return k;
        } catch (SecurityException ignored) { }
        return null;
    }

    private Location anyFix() {
        Location f = TripService.lastFix;
        if (f != null) return f;
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            return lm == null ? null : lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        } catch (SecurityException e) {
            return null;
        }
    }

    private String readStream(InputStream is) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = is.read(buf)) != -1) {
            bos.write(buf, 0, n);
        }
        is.close();
        return bos.toString("UTF-8");
    }

    /** Saves backup to Downloads/MageLori/magelori_auto_backup.json on Android 10+ (survives app reinstall/data wipe) */
    private void savePublicDownloadBackup(byte[] data) {
        if (Build.VERSION.SDK_INT < 29) return;
        try {
            ContentResolver cr = getContentResolver();
            Uri collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            String relPath = Environment.DIRECTORY_DOWNLOADS + "/MageLori/";
            Uri existingUri = null;

            String[] proj = new String[]{MediaStore.MediaColumns._ID};
            String sel = MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?";
            Cursor c = cr.query(collection, proj, sel, new String[]{BACKUP_FILE, relPath}, null);
            if (c != null) {
                if (c.moveToFirst()) {
                    long id = c.getLong(0);
                    existingUri = ContentUris.withAppendedId(collection, id);
                }
                c.close();
            }

            if (existingUri != null) {
                OutputStream os = cr.openOutputStream(existingUri, "wt");
                if (os != null) {
                    os.write(data);
                    os.flush();
                    os.close();
                    return;
                }
            }

            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, BACKUP_FILE);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, relPath);
            Uri uri = cr.insert(collection, cv);
            if (uri != null) {
                OutputStream os = cr.openOutputStream(uri, "wt");
                if (os != null) {
                    os.write(data);
                    os.flush();
                    os.close();
                }
            }
        } catch (Exception ignored) { }
    }

    /** Loads backup from Downloads/MageLori/magelori_auto_backup.json if internal backup is missing */
    private String loadPublicDownloadBackup() {
        if (Build.VERSION.SDK_INT < 29) return "";
        try {
            ContentResolver cr = getContentResolver();
            Uri collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            String relPath = Environment.DIRECTORY_DOWNLOADS + "/MageLori/";
            String[] proj = new String[]{MediaStore.MediaColumns._ID};
            String sel = MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?";
            Cursor c = cr.query(collection, proj, sel, new String[]{BACKUP_FILE, relPath}, null);
            if (c != null) {
                if (c.moveToFirst()) {
                    long id = c.getLong(0);
                    c.close();
                    Uri uri = ContentUris.withAppendedId(collection, id);
                    InputStream is = cr.openInputStream(uri);
                    if (is != null) {
                        return readStream(is);
                    }
                } else {
                    c.close();
                }
            }
        } catch (Exception ignored) { }
        return "";
    }

    /** Called from JavaScript as window.AndroidTrip */
    public class TripBridge {

        // ---------------- Auto-Backup (Internal + Downloads/MageLori) ----------------

        @JavascriptInterface
        public void saveBackup(String json) {
            if (json == null || json.length() < 10) return;
            byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
            try {
                File f = new File(getFilesDir(), BACKUP_FILE);
                File tmp = new File(getFilesDir(), BACKUP_FILE + ".tmp");
                FileOutputStream fos = new FileOutputStream(tmp);
                fos.write(bytes);
                fos.flush();
                fos.close();
                if (!tmp.renameTo(f)) {
                    FileOutputStream fos2 = new FileOutputStream(f);
                    fos2.write(bytes);
                    fos2.close();
                    tmp.delete();
                }
            } catch (Exception ignored) { }
            savePublicDownloadBackup(bytes);
        }

        @JavascriptInterface
        public String loadBackup() {
            try {
                File f = new File(getFilesDir(), BACKUP_FILE);
                if (f.exists()) {
                    String s = readStream(new FileInputStream(f));
                    if (s != null && s.length() > 10) return s;
                }
            } catch (Exception ignored) { }
            return loadPublicDownloadBackup();
        }

        // ---------------- Odometer (independent of hire) ----------------

        @JavascriptInterface
        public double takeOdoMeters() {
            synchronized (TripService.LOCK) {
                SharedPreferences sp = tripPrefs();
                double m = TripService.getD(sp, "odoPend", 0d);
                SharedPreferences.Editor e = sp.edit();
                TripService.putD(e, "odoPend", 0d);
                e.apply();
                return m;
            }
        }

        @JavascriptInterface
        public double peekOdoMeters() {
            synchronized (TripService.LOCK) {
                return TripService.getD(tripPrefs(), "odoPend", 0d);
            }
        }

        @JavascriptInterface
        public void setOdoBase(double km) {
            synchronized (TripService.LOCK) {
                SharedPreferences.Editor e = tripPrefs().edit();
                TripService.putD(e, "odoBase", km);
                e.apply();
            }
        }

        @JavascriptInterface
        public String gpsStatus() {
            if (!hasLocationPermission()) return "perm";
            return gpsEnabled() ? "ok" : "gps_off";
        }

        // ---------------- Hire ON/OFF (separate function) ----------------

        @JavascriptInterface
        public String hireStart() {
            if (!License.isPro(MainActivity.this)) return "pro";
            if (!hasLocationPermission()) {
                requestLocationPerms();
                return "perm";
            }
            if (!gpsEnabled()) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                });
                return "gps_off";
            }
            Location fix = freshFix();
            synchronized (TripService.LOCK) {
                SharedPreferences.Editor e = tripPrefs().edit();
                e.putBoolean("hireOn", true);
                TripService.putD(e, "hireM", 0d);
                e.putLong("hireStartMs", System.currentTimeMillis());
                e.remove("startName");
                if (fix != null) {
                    e.putBoolean("hasStart", true);
                    TripService.putD(e, "startLat", fix.getLatitude());
                    TripService.putD(e, "startLng", fix.getLongitude());
                } else {
                    e.putBoolean("hasStart", false);
                }
                e.apply();
            }
            if (fix != null) TripService.resolveStartName(MainActivity.this, fix.getLatitude(), fix.getLongitude());
            startTracking();
            return "ok";
        }

        @JavascriptInterface
        public String hireStop() {
            JSONObject o = new JSONObject();
            Location end = anyFix();
            synchronized (TripService.LOCK) {
                SharedPreferences sp = tripPrefs();
                try {
                    o.put("meters", TripService.getD(sp, "hireM", 0d));
                    o.put("startMs", sp.getLong("hireStartMs", System.currentTimeMillis()));
                    boolean hasStart = sp.getBoolean("hasStart", false);
                    o.put("hasStart", hasStart);
                    if (hasStart) {
                        o.put("startLat", TripService.getD(sp, "startLat", 0d));
                        o.put("startLng", TripService.getD(sp, "startLng", 0d));
                        o.put("startName", sp.getString("startName", ""));
                    }
                    o.put("hasEnd", end != null);
                    if (end != null) {
                        o.put("endLat", end.getLatitude());
                        o.put("endLng", end.getLongitude());
                    }
                } catch (JSONException ignored) { }
                sp.edit().putBoolean("hireOn", false).putBoolean("hasStart", false).remove("startName").apply();
            }
            if (TripService.isRunning) {
                TripService.updateNotification(MainActivity.this, false);
            } else {
                startTracking();
            }
            return o.toString();
        }

        @JavascriptInterface
        public boolean isHireActive() {
            return tripPrefs().getBoolean("hireOn", false);
        }

        @JavascriptInterface
        public double getHireMeters() {
            synchronized (TripService.LOCK) {
                return TripService.getD(tripPrefs(), "hireM", 0d);
            }
        }

        @JavascriptInterface
        public void geocode(final String kind, final double lat, final double lng) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String n = TripService.placeName(MainActivity.this, lat, lng);
                    final String js = "placeResolved(" + JSONObject.quote(kind) + ","
                            + JSONObject.quote(n == null ? "" : n) + ")";
                    if (isUiAlive()) {
                        webView.post(new Runnable() {
                            @Override
                            public void run() {
                                if (isUiAlive()) {
                                    webView.evaluateJavascript(js, null);
                                }
                            }
                        });
                    }
                }
            }).start();
        }

        @JavascriptInterface
        public String getLocation() {
            JSONObject o = new JSONObject();
            try {
                if (!hasLocationPermission()) {
                    o.put("ok", false);
                    o.put("reason", "perm");
                } else if (!gpsEnabled()) {
                    o.put("ok", false);
                    o.put("reason", "gps_off");
                } else {
                    Location f = freshFix();
                    if (f == null) {
                        o.put("ok", false);
                        o.put("reason", "nofix");
                    } else {
                        o.put("ok", true);
                        o.put("lat", f.getLatitude());
                        o.put("lng", f.getLongitude());
                        o.put("acc", f.hasAccuracy() ? f.getAccuracy() : -1);
                    }
                }
            } catch (JSONException ignored) { }
            return o.toString();
        }

        @JavascriptInterface
        public void findStations(double lat, double lng) {
            StationFinder.find(MainActivity.this, lat, lng, new StationFinder.Callback() {
                @Override
                public void done(final String json) {
                    if (isUiAlive()) {
                        webView.post(new Runnable() {
                            @Override
                            public void run() {
                                if (isUiAlive()) {
                                    webView.evaluateJavascript("window.stationsFound&&stationsFound(" + json + ")", null);
                                }
                            }
                        });
                    }
                }
            });
        }

        // ---------------- Service reminders ----------------

        @JavascriptInterface
        public void setService(double dueOdo, double warnKm, double interval) {
            if (!License.isPro(MainActivity.this)) dueOdo = 0;
            tripPrefs().edit()
                    .putFloat("svcDue", (float) dueOdo)
                    .putFloat("svcWarnKm", (float) warnKm)
                    .putFloat("svcInterval", (float) interval)
                    .apply();
        }

        @JavascriptInterface
        public void checkOdo(double odo) {
            if (!License.isPro(MainActivity.this)) return;
            ServiceReminder.check(MainActivity.this, odo);
        }

        // ---------------- Free / Pro license ----------------

        @JavascriptInterface
        public boolean isPro() {
            return License.isPro(MainActivity.this);
        }

        @JavascriptInterface
        public String getDeviceId() {
            return License.deviceCode(MainActivity.this);
        }

        @JavascriptInterface
        public boolean activatePro(String key) {
            return License.activate(MainActivity.this, key);
        }

        @JavascriptInterface
        public void copyText(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) {
                        cm.setPrimaryClip(ClipData.newPlainText("text", text));
                        Toast.makeText(MainActivity.this, "Copy කළා", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void shareText(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(i, "Device ID යවන්න"));
                }
            });
        }

        @JavascriptInterface
        public void askNotify() {
            requestNotifyPermIfNeeded();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
