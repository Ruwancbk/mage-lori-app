package lk.ruwancbk.magelori;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

/** Vehicle service reminders: warning 300 km before, and again when the service is due. */
final class ServiceReminder {
    private ServiceReminder() { }

    /** odo = current odometer (km). Notifies once per due-odometer for each stage. */
    static void check(Context c, double odo) {
        SharedPreferences sp = c.getSharedPreferences(TripService.PREFS, Context.MODE_PRIVATE);
        float due = sp.getFloat("svcDue", 0f);
        if (due <= 0f) return;
        float warnKm = sp.getFloat("svcWarnKm", 300f);
        float interval = sp.getFloat("svcInterval", 5000f);
        if (odo >= due) {
            if (Math.abs(sp.getFloat("dueSent", -1f) - due) > 0.5f) {
                show(c, 3, "🔧 Service කරන්න කාලය හරි!",
                        "කි.මී. " + (int) interval + " සම්පූර්ණයි (Odometer " + (int) odo
                                + " km). දැන් වාහනය service කරන්න.");
                sp.edit().putFloat("dueSent", due).putFloat("warnSent", due).apply();
            }
        } else if (odo >= due - warnKm) {
            if (Math.abs(sp.getFloat("warnSent", -1f) - due) > 0.5f) {
                int left = (int) Math.ceil(due - odo);
                show(c, 2, "🔧 Service කාලය ළඟයි",
                        "Service එකට තව km " + left + "ක් පමණ ඉතිරියි (Odometer " + (int) odo + " km).");
                sp.edit().putFloat("warnSent", due).apply();
            }
        }
    }

    static void show(Context c, int id, String title, String text) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, id, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("service", "Service reminders",
                    NotificationManager.IMPORTANCE_HIGH);
            nm.createNotificationChannel(ch);
            b = new Notification.Builder(c, "service");
        } else {
            b = new Notification.Builder(c).setDefaults(Notification.DEFAULT_ALL)
                    .setPriority(Notification.PRIORITY_HIGH);
        }
        b.setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentIntent(pi)
                .setAutoCancel(true);
        nm.notify(id, b.build());
    }
}
