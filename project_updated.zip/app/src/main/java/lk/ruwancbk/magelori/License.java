package lk.ruwancbk.magelori;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.UUID;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * Free / Pro licensing.
 * Device code  = SHA-256("MAGELORI|" + ANDROID_ID), base32, first 12 chars -> XXXX-XXXX-XXXX
 * Pro key      = first 10 bytes of HMAC-SHA256(SECRET, "MAGELORI-PRO|" + deviceCode) -> XXXX-XXXX-XXXX-XXXX
 * The same secret is used by owner-tools/keygen.py and keygen.html. Keep those files PRIVATE.
 */
final class License {
    private License() { }

    private static final String PREFS = "license";
    private static final String ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    // SECRET (hex) - must match owner-tools. Change before publishing your own build.
    private static final String SECRET_HEX = "8e6ced92cc7c162c6ef7e2f39d4cf589193c5741e6d40ac8cf3b3adf17d4b78d";

    private static volatile Boolean cached;

    private static byte[] hex(String s) {
        byte[] b = new byte[s.length() / 2];
        for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(s.substring(2 * i, 2 * i + 2), 16);
        return b;
    }

    private static String b32(byte[] d, int n) {
        StringBuilder sb = new StringBuilder();
        int buf = 0, bits = 0;
        for (int i = 0; i < n; i++) {
            buf = (buf << 8) | (d[i] & 0xff);
            bits += 8;
            while (bits >= 5) {
                sb.append(ALPHA.charAt((buf >> (bits - 5)) & 31));
                bits -= 5;
            }
            buf &= (1 << bits) - 1;
        }
        return sb.toString();
    }

    private static String group(String s, int size) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            if (i > 0 && i % size == 0) sb.append('-');
            sb.append(s.charAt(i));
        }
        return sb.toString();
    }

    private static String clean(String s) {
        return s == null ? "" : s.replaceAll("[^A-Za-z0-9]", "").toUpperCase();
    }

    /** Stable per-device code shown to the user (send it to the owner to get a Pro key). */
    static String deviceCode(Context c) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String id = null;
        try {
            id = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ANDROID_ID);
        } catch (Exception ignored) { }
        if (id == null || id.length() < 8 || id.equals("9774d56d682e549c")) {
            id = sp.getString("fallbackId", null);
            if (id == null) {
                id = UUID.randomUUID().toString();
                sp.edit().putString("fallbackId", id).apply();
            }
        }
        try {
            byte[] h = MessageDigest.getInstance("SHA-256").digest(("MAGELORI|" + id).getBytes(StandardCharsets.UTF_8));
            return group(b32(h, 8).substring(0, 12), 4);
        } catch (Exception e) {
            return "ERROR";
        }
    }

    static String expectedKey(String deviceCode) {
        try {
            Mac m = Mac.getInstance("HmacSHA256");
            m.init(new SecretKeySpec(hex(SECRET_HEX), "HmacSHA256"));
            byte[] r = m.doFinal(("MAGELORI-PRO|" + clean(deviceCode)).getBytes(StandardCharsets.UTF_8));
            return group(b32(r, 10), 4);
        } catch (Exception e) {
            return "";
        }
    }

    static boolean verify(Context c, String key) {
        String k = clean(key);
        return k.length() == 16 && k.equals(clean(expectedKey(deviceCode(c))));
    }

    static boolean isPro(Context c) {
        Boolean v = cached;
        if (v != null) return v;
        String key = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("key", "");
        boolean ok = verify(c, key);
        cached = ok;
        return ok;
    }

    static boolean activate(Context c, String key) {
        if (!verify(c, key)) return false;
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("key", clean(key)).apply();
        cached = true;
        return true;
    }

    static void deactivate(Context c) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove("key").apply();
        cached = false;
    }
}
