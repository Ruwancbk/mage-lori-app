package lk.ruwancbk.magelori;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;

import java.util.List;
import java.util.Locale;

/**
 * Foreground service with ONE GPS stream that feeds two independent things:
 *  1. Odometer  - always counts while the app is open and GPS is on (odoPend metres, merged into the odometer by the web UI).
 *  2. Hire trip - separate counter + start/end location, only between hire Start and End.
 */
public class TripService extends Service implements LocationListener {
    static final String PREFS = "trip";
    static final Object LOCK = new Object();
    static volatile Location lastFix;

    private LocationManager lm;
    private Location last;

    // ---- double <-> SharedPreferences helpers (float loses precision on 6-digit odometers) ----
    static double getD(SharedPreferences sp, String k, double def) {
        return sp.contains(k) ? Double.longBitsToDouble(sp.getLong(k, 0L)) : def;
    }

    static void putD(SharedPreferences.Editor e, String k, double v) {
        e.putLong(k, Double.doubleToRawLongBits(v));
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        boolean hire = sp.getBoolean("hireOn", false);
        startForegroundCompat(hire);
        if (!sp.getBoolean("tracking", false) && !hire) {
            stopSelf();
            return START_NOT_STICKY;
        }
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            lm.removeUpdates(this);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this);
        } catch (SecurityException | IllegalArgumentException e) {
            stopSelf();
        }
        return START_STICKY;
    }

    private void startForegroundCompat(boolean hire) {
        Notification n = buildNotification(hire);
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } else {
            startForeground(1, n);
        }
    }

    private Notification buildNotification(boolean hire) {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel ch = new NotificationChannel("trip", "GPS", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
            b = new Notification.Builder(this, "trip");
        } else {
            b = new Notification.Builder(this);
        }
        b.setContentTitle(hire ? "හයර් Start" : "මගේ ලොරිය")
                .setContentText(hire ? "GPS දුර සහ ස්ථාන සටහන් වෙමින් පවතී" : "Odometer GPS ක්‍රියාත්මකයි")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentIntent(pi)
                .setOngoing(true);
        return b.build();
    }

    @Override
    public void onLocationChanged(Location loc) {
        if (loc.hasAccuracy() && loc.getAccuracy() > 40f) return;
        lastFix = loc;
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        synchronized (LOCK) {
            boolean hire = sp.getBoolean("hireOn", false);

            // Hire just started and we had no recent fix: this first good fix is the trip start location.
            if (hire && !sp.getBoolean("hasStart", false)) {
                SharedPreferences.Editor e = sp.edit();
                e.putBoolean("hasStart", true);
                putD(e, "startLat", loc.getLatitude());
                putD(e, "startLng", loc.getLongitude());
                e.apply();
                resolveStartName(this, loc.getLatitude(), loc.getLongitude());
            }

            if (last == null) {
                last = loc;
                return;
            }
            float d = last.distanceTo(loc);
            float acc = loc.hasAccuracy() ? loc.getAccuracy() : 10f;
            if (d < Math.max(6f, acc * 0.5f)) return;
            if (loc.hasSpeed() && loc.getSpeed() < 0.6f && d < 25f) return;
            long dt = Math.abs(loc.getTime() - last.getTime()) / 1000L;
            if (dt > 0 && d / dt > 70f) {
                last = loc;
                return;
            }
            last = loc;

            double pend = getD(sp, "odoPend", 0d) + d;
            SharedPreferences.Editor e = sp.edit();
            putD(e, "odoPend", pend);
            if (hire) putD(e, "hireM", getD(sp, "hireM", 0d) + d);
            e.apply();

            double base = getD(sp, "odoBase", -1d);
            if (base >= 0d) ServiceReminder.check(this, base + pend / 1000.0);
        }
    }

    /** Looks up the start place name in the background and stores it for the hire form. */
    static void resolveStartName(final Context ctx, final double lat, final double lng) {
        final Context app = ctx.getApplicationContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                String name = placeName(app, lat, lng);
                if (name == null || name.length() == 0) return;
                SharedPreferences sp = app.getSharedPreferences(PREFS, MODE_PRIVATE);
                synchronized (LOCK) {
                    if (sp.getBoolean("hireOn", false) && sp.getBoolean("hasStart", false)
                            && Math.abs(getD(sp, "startLat", 0d) - lat) < 1e-7) {
                        sp.edit().putString("startName", name).apply();
                    }
                }
            }
        }).start();
    }

    /** Reverse geocode (needs internet). Returns null/"" when unavailable. Call off the main thread. */
    @SuppressWarnings("deprecation")
    static String placeName(Context ctx, double lat, double lng) {
        try {
            if (!Geocoder.isPresent()) return null;
            Geocoder g = new Geocoder(ctx, new Locale("si", "LK"));
            List<Address> list = g.getFromLocation(lat, lng, 1);
            if (list == null || list.isEmpty()) return null;
            Address a = list.get(0);
            String place = a.getSubLocality();
            if (place == null) place = a.getThoroughfare();
            String city = a.getLocality();
            if (city == null) city = a.getSubAdminArea();
            StringBuilder sb = new StringBuilder();
            if (place != null) sb.append(place);
            if (city != null && !city.equals(place)) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(city);
            }
            if (sb.length() == 0 && a.getMaxAddressLineIndex() >= 0) sb.append(a.getAddressLine(0));
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) { }

    @Override
    public void onProviderEnabled(String provider) {
        last = null; // don't count the jump made while GPS was off
    }

    @Override
    public void onProviderDisabled(String provider) {
        last = null;
    }

    @Override
    public void onDestroy() {
        if (lm != null) {
            try { lm.removeUpdates(this); } catch (SecurityException ignored) { }
        }
        super.onDestroy();
    }
}
